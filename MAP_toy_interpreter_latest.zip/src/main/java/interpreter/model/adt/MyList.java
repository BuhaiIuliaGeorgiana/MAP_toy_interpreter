package interpreter.model.adt;

import interpreter.exceptions.ADTException;

import java.util.ArrayList;
import java.util.List;

public class MyList<T> implements IList<T>{
    private final ArrayList<T> arr = new ArrayList<>();
    @Override
    public void add(T element) {
        arr.add(element);
    }

    @Override
    public T get(int index) throws ADTException {
        if(arr.size() <= index || index < 0) throw new ADTException("list: get an invalid index");
        return arr.get(index);
    }

    @Override
    public int size() {
        return arr.size();
    }

    @Override
    public List<T> toList() {
        return List.copyOf(arr);
    }

    @Override
    public String toString(){
        return arr.toString();
    }
}
